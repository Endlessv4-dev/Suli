<?php 

    echo "asd";

?>